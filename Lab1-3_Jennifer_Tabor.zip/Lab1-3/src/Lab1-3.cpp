//============================================================================
// Name        : Lab1-3.cpp
// Author      : Jennifer Tabor
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Lab 1-3 Up to Speed in C++
//============================================================================



#include <algorithm>
#include <iostream>
using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================
// FIXME (1): Define a data structure to hold bid information together as a single unit of storage.

	struct Bids {
    string title;
    string fund;
    string vehicleID ;
    double bidAmt ;
};

// FIXME (4): Display the bid values passed in data structure
/**
* Display the bid information
* @param Bids data structure containing the bid info
*/

void displayBid(Bids bidItem) {

    cout << "Title: " << bidItem.title << endl;
    cout << "Fund: " << bidItem.fund << endl;
    cout << "Vehicle: " << bidItem.vehicleID << endl;
    cout << "Bid Amount: $" << bidItem.bidAmt << endl;
}

/**
* Simple C function to convert a string to a double
* after stripping out unwanted char
*
*
* @param ch The character to strip out
*/
	double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

// FIXME (3): Store input values in data structure
/**
* Prompt user for bid information
*
* @return data structure containing the bid info
*/

    void getBid(Bids & bidInfo) {
    cout << "Enter title: ";
    cin.ignore();
    getline(cin, bidInfo.title);

    cout << "Enter fund: ";
    cin >> bidInfo.fund;

    cout << "Enter vehicle: ";
    cin.ignore();
    getline(cin, bidInfo.vehicleID);

    cout << "Enter amount: ";
    string strAmount;
    getline(cin, strAmount);
    bidInfo.bidAmt = strToDouble(strAmount, '$');
    //void method does not have a return value
}

/**
* The one and only main() method
*/

int main() {

    //FIXME (2): Declare instance of data structure to hold bid information
    Bids bidInfo;
    // loop to display menu until exit chosen
    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << " 1. Enter Bid" << endl;
        cout << " 2. Display Bid" << endl;
        cout << " 9. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        // FIXME (5): Complete the method calls then test the program

        switch (choice) {

           case 1:
                getBid(bidInfo);
                break;

            case 2:
                displayBid(bidInfo);
                break;

            // when user wants to quit
            // exit the program
            case 9 :
            	cout << "Good Bye." << endl;
            	exit(0);
            default : break;

        }

    }



    return 0;

}
